from django.shortcuts import render
import math

def emi_calculator(principal, annual_interest_rate, tenure_years):
    if annual_interest_rate == 0:
        raise ZeroDivisionError("Interest rate cannot be zero")
    
    monthly_interest_rate = annual_interest_rate / (12 * 100)
    tenure_months = tenure_years * 12
    
    emi = (principal * monthly_interest_rate * math.pow(1 + monthly_interest_rate, tenure_months)) / \
        (math.pow(1 + monthly_interest_rate, tenure_months) - 1)
    
    return round(emi, 2)

def emi_view(request):
    context = {}
    if request.method == 'POST':
        try:
            principal = float(request.POST['principal'])
            annual_interest_rate = float(request.POST['annual_interest_rate'])
            tenure_years = int(request.POST['tenure_years'])

            emi = emi_calculator(principal, annual_interest_rate, tenure_years)
            context['emi'] = emi
        except ZeroDivisionError:
            context['error'] = 'Interest rate cannot be zero.'
        except ValueError:
            context['error'] = 'Invalid input. Please enter valid numbers.'
    return render(request, 'emi_calculator.html', context)

def sip_calculator(monthly_investment, annual_interest_rate, years):
    if annual_interest_rate < 0:
        raise ValueError("Interest rate must not be negative")
    
    monthly_interest_rate = annual_interest_rate / (12 * 100)
    months = years * 12
    future_value = monthly_investment * ((math.pow(1 + monthly_interest_rate, months) - 1) / monthly_interest_rate) * (1 + monthly_interest_rate)
    return round(future_value, 2)

def sip_view(request):
    context = {}
    if request.method == 'POST':
        try:
            monthly_investment = float(request.POST['monthly_investment'])
            annual_interest_rate = float(request.POST['annual_interest_rate'])
            years = int(request.POST['years'])

            sip = sip_calculator(monthly_investment, annual_interest_rate, years)
            context['sip'] = sip
        except ValueError as e:
            context['error'] = str(e)
    return render(request, 'sip_calculator.html', context)
 # assuming your calculator is here

def fd_calculator_view(request):
    if request.method == 'POST':
        form = FDForm(request.POST)
        if form.is_valid():
            principal = form.cleaned_data['principal']
            interest = form.cleaned_data['interest']
            years = form.cleaned_data['years']
            amount = fd_calculator(principal, interest, years)
            return render(request, 'fd_result.html', {
                'principal': principal,
                'interest': interest,
                'years': years,
                'amount': amount
            })
    else:
        form = FDForm()
    return render(request, 'fd_calculator.html', {'form': form})


# Create your views here.
