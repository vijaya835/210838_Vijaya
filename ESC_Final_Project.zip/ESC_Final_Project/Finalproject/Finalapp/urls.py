from django.urls import path
from . import views

urlpatterns = [
    path('emi/', views.emi_view, name='emi_calculator'),
    path('sip/', views.sip_view, name='sip_calculator'),
]