from django import forms

class FDForm(forms.Form):
    principal = forms.DecimalField(label='Principal Amount', min_value=0)
    interest = forms.DecimalField(label='Annual Interest Rate (%)', min_value=0)
    years = forms.IntegerField(label='Tenure (Years)', min_value=1)
