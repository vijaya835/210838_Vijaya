import math

# 1. EMI Calculator
def emi_calculator(principal, annual_interest_rate, tenure_years):
    if annual_interest_rate == 0:
        raise ZeroDivisionError("Interest rate cannot be zero")
    
    monthly_interest_rate = annual_interest_rate / (12 * 100)
    tenure_months = tenure_years * 12
    
    emi = (principal * monthly_interest_rate * math.pow(1 + monthly_interest_rate, tenure_months)) / \
        (math.pow(1 + monthly_interest_rate, tenure_months) - 1)
    
    return round(emi, 2)


# 2. SIP Calculator
def sip_calculator(monthly_investment, annual_interest_rate, years):
    if annual_interest_rate < 0:
        raise ValueError("Interest rate must not be negative")
    
    monthly_interest_rate = annual_interest_rate / (12 * 100)
    months = years * 12
    future_value = monthly_investment * ((math.pow(1 + monthly_interest_rate, months) - 1) / monthly_interest_rate) * (1 + monthly_interest_rate)
    return round(future_value, 2)

# 3. FD Calculator
def fd_calculator(principal, annual_interest_rate, years):
    if principal <= 0:
        raise ValueError("Principal must be positive")
    
    amount = principal * math.pow(1 + annual_interest_rate / 100, years)
    return round(amount, 2)

# 4. RD Calculator
def rd_calculator(monthly_deposit, annual_interest_rate, years):
    if monthly_deposit <= 0:
        raise ValueError("Monthly deposit must be positive")
    
    monthly_interest_rate = annual_interest_rate / (12 * 100)
    months = years * 12
    maturity_value = monthly_deposit * ((math.pow(1 + monthly_interest_rate, months) - 1) / monthly_interest_rate) * (1 + monthly_interest_rate)
    return round(maturity_value, 2)

# 5. Retirement Savings Estimator
def retirement_savings_estimator(current_savings, monthly_addition, annual_interest_rate, tenure_years):
    future_value = current_savings * math.pow(1 + annual_interest_rate / 100, tenure_years)
    future_value += sip_calculator(monthly_addition, annual_interest_rate, tenure_years)
    return future_value

# 6. Home Loan Eligibility Estimator
def home_loan_eligibility_estimator(monthly_income, monthly_expenses, annual_interest_rate, tenure_years):
    if monthly_income == 0 or annual_interest_rate == 0:
        raise ZeroDivisionError("Income and interest rate must be greater than zero.")
    
    savings = monthly_income - monthly_expenses
    eligible_amount = savings * 12 * tenure_years
    return round(eligible_amount, 2)

# 7. Credit Card Interest Calculator
def credit_card_interest_calculator(balance, annual_interest_rate, minimum_payment_rate, months):
    total_balance = balance
    for _ in range(months):
        interest = total_balance * (annual_interest_rate / (12 * 100))
        minimum_payment = total_balance * (minimum_payment_rate / 100)
        total_balance = total_balance + interest - minimum_payment
    return total_balance

# 8. Taxable Income Calculator
def taxable_income_calculator(gross_income, deductions):
    taxable_income = gross_income - deductions
    return max(taxable_income, 0)

# 9. Simple Budget Planner
def simple_budget_planner(monthly_income, monthly_expenses):
    savings = monthly_income - monthly_expenses
    if savings > 0:
        return {"status": "Surplus", "savings": savings, "suggestion": "Invest your surplus wisely."}
    elif savings < 0:
        return {"status": "Deficit", "savings": savings, "suggestion": "Reduce expenses or increase income."}
    else:
        return {"status": "Break-even", "savings": savings, "suggestion": "Maintain your current budget."}

# 10. Net Worth Calculator
def net_worth_calculator(assets, liabilities):
    net_worth = sum(assets) - sum(liabilities)
    return net_worth