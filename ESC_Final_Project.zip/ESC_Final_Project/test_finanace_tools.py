import unittest
import finance_tools  # Assuming the functions are in finance_tools.py

class TestFinanceTools(unittest.TestCase):

    def test_emi_calculator(self):
        # Check if EMI calculation is correct for a loan of 100,000, 10% interest, for 10 years
        self.assertAlmostEqual(finance_tools.emi_calculator(100000, 10, 10), 1321.51, places=2)
        self.assertAlmostEqual(finance_tools.emi_calculator(50000, 12, 5), 1112.22, places=2)
        with self.assertRaises(ZeroDivisionError):
            finance_tools.emi_calculator(100000, 0, 10)  # Invalid: Interest rate can't be zero

    def test_sip_calculator(self):
        # Check SIP calculation for monthly investment of 1000, 12% interest, for 5 years
        self.assertAlmostEqual(finance_tools.sip_calculator(1000, 12, 5), 82486.37, places=2)
        self.assertAlmostEqual(finance_tools.sip_calculator(2000, 10, 7), 243916.68, places=2)
        with self.assertRaises(ValueError):
            finance_tools.sip_calculator(1000, -5, 5)  # Invalid: Negative interest rate

    def test_fd_calculator(self):
        # Check FD calculation for a principal of 100,000, 6% interest, for 5 years
        self.assertAlmostEqual(finance_tools.fd_calculator(100000, 6, 5), 133822.56, places=2)
        self.assertAlmostEqual(finance_tools.fd_calculator(200000, 7, 10), 393430.27, places=2)
        with self.assertRaises(ValueError):
            finance_tools.fd_calculator(0, 6, 5)  # Invalid: Principal should be positive

    def test_rd_calculator(self):
        # Check RD calculation for monthly deposit of 5000, 6% interest, for 5 years
        self.assertAlmostEqual(finance_tools.rd_calculator(5000, 6, 5), 350594.40, places=2)
        self.assertAlmostEqual(finance_tools.rd_calculator(1000, 8, 10), 184165.68, places=2)
        with self.assertRaises(ValueError):
            finance_tools.rd_calculator(0, 5, 5)  # Invalid: Monthly deposit should be positive

    def test_retirement_savings_estimator(self):
        # Check retirement savings estimator for current savings of 50,000, monthly addition of 1000, 6% interest, 20 years
        self.assertAlmostEqual(finance_tools.retirement_savings_estimator(50000, 1000, 6, 20), 624707.87, places=2)
        self.assertAlmostEqual(finance_tools.retirement_savings_estimator(200000, 2000, 8, 15), 1331124.11, places=2)

    def test_home_loan_eligibility_estimator(self):
    # (Income - Expenses) * 12 * years
        self.assertAlmostEqual(finance_tools.home_loan_eligibility_estimator(50000, 20000, 12, 20), 7200000.00, places=2)
        self.assertAlmostEqual(finance_tools.home_loan_eligibility_estimator(70000, 25000, 10, 10), 5400000.00, places=2)
        self.assertEqual(finance_tools.home_loan_eligibility_estimator(50000, 50000, 10, 10), 0)


    def test_credit_card_interest_calculator(self):
        # Check credit card interest calculation for balance of 5000, 18% annual interest, 5% minimum payment, 12 months
        self.assertAlmostEqual(finance_tools.credit_card_interest_calculator(5000, 18, 5, 12), 3260.60, places=2)
        self.assertAlmostEqual(finance_tools.credit_card_interest_calculator(10000, 15, 10, 6), 5772.94, places=2)

    def test_taxable_income_calculator(self):
        # Check taxable income calculation for gross income of 100,000, and deductions of 20,000
        self.assertEqual(finance_tools.taxable_income_calculator(100000, 20000), 80000)
        self.assertEqual(finance_tools.taxable_income_calculator(50000, 6000), 44000)
        self.assertEqual(finance_tools.taxable_income_calculator(20000, 25000), 0)  # Invalid: deductions > income

    def test_simple_budget_planner(self):
        # Check budget planner for monthly income of 50,000, and expenses of 30,000
        self.assertEqual(finance_tools.simple_budget_planner(50000, 30000), {"status": "Surplus", "savings": 20000, "suggestion": "Invest your surplus wisely."})
        self.assertEqual(finance_tools.simple_budget_planner(20000, 25000), {"status": "Deficit", "savings": -5000, "suggestion": "Reduce expenses or increase income."})
        self.assertEqual(finance_tools.simple_budget_planner(50000, 50000), {"status": "Break-even", "savings": 0, "suggestion": "Maintain your current budget."})

    def test_net_worth_calculator(self):
        # Check net worth calculation for assets of 100,000 and liabilities of 50,000
        self.assertEqual(finance_tools.net_worth_calculator([100000, 50000], [20000, 30000]), 100000)
        self.assertEqual(finance_tools.net_worth_calculator([100000], [100000]), 0)
        self.assertEqual(finance_tools.net_worth_calculator([0], [5000]), -5000)

if __name__ == '__main__':
    unittest.main()
