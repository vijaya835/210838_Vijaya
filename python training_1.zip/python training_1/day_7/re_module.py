import re 
p=r"\\d+\\.?\\d*"
text = "temperature in TRV 34.56 and in BLR 32"
re.match(p,text)
re.search(p,text)
