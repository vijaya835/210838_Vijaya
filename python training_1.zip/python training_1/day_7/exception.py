def nfactorial(n):
    if n <= 0:
        raise ValueError("Input must be a positive integer greater than 0.")
    
    factorial = 1
    for i in range(1, n + 1):
        factorial *= i
    return factorial

try:
    print("Factorial of 5:", nfactorial(5)) 
    print("Factorial of 0:", nfactorial(0)) 
except Exception as e: 
    print(f"Exception Occured! {e}")
else: 
    print("Completed operations")
finally: 
    print("Thank you!")