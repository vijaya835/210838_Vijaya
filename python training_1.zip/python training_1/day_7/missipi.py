def spansub(stri, substri):
    if substri == "" or stri == "":
        raise ValueError("Both string and substring must be non-empty")
    
    li = []  # local list to store the spans
    x = len(substri)
    
    # Loop through the string to find all occurrences of the substring
    for i in range(len(stri) - x + 1):  # only iterate till the last possible starting position
        subs = x + i
        if substri == stri[i:subs]:
            li.append((i, subs))
    
    # Print the number of occurrences and their spans
    print(len(li), li)

# Main code execution
if __name__ == "__main__":
    try:
        strio = input("Enter the string: ")
        substrio = input("Enter the substring: ")
        spansub(strio, substrio)  # Call the spansub function
    except Exception as e:
        print(f"Exception occurred! {e}")
    else:
        print("Completed operations")
    finally:
        print("Thank you!")
  