class Car:
   
    ncar = 0

    def __init__(self, brand, model, year, mileage, fuel_level=0):  
        self.brand = brand
        self.model = model
        self.year = year
        self.mileage = mileage
        self.fuel_level = fuel_level  
     

    def drive(self, distance):
        if self.fuel_level > 0:
            self.mileage += distance  
            self.fuel_level -= distance * 0.3
            if self.fuel_level < 0:
                self.fuel_level = 0  
        else:
            print("Not enough fuel to drive!")

    def refuel(self, amount):
        self.fuel_level += amount  

    def display_info(self):
        print("\nCar Details:")
        print("Brand".ljust(20), "->", self.brand)
        print("Model".ljust(20), "->", self.model)
        print("Year".ljust(20), "->", self.year)
        print("Mileage".ljust(20), "->", self.mileage)
        print("Fuel Level".ljust(20), "->", self.fuel_level)
        print("-" * 40)


c = Car("VW", "Polo", 2025, 130, fuel_level=50)  
c.display_info() 
c.drive(10)  
c.refuel(20) 
c.display_info()  

class ElectricCar(Car):
    def __init__(self,battery_capacity,charge_level):
        self.battery_capacity = battery_capacity
        self.charge_level = charge_level 
        super().__init__(battery_capacity,charge_level)
    
    def charge(self,amount):
            self.amount = min(self.charge_level + amount, 100)
    def display_info(self):
        super().display_info()
        print(f"Battery Capacity: {self.battery_capacity} kWh\nCharge Level: {self.charge_level}%")

    def print(self):
        super().print() # To print the parent side details
        print("-"*80)
        print("battery_capacity".ljust(20), ' = ', self.battery_capacity)
        print("charge_level".ljust(20), ' = ', self.charge_level)

c = ElectricCar("100","60")
# Calling functions from parent side
c.battery_capacity(10)
c.charge_level(10)
c.print()
