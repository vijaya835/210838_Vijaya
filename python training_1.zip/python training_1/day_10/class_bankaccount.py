# Base class: BankAccount
class BankAccount:
    def __init__(self, account_number, balance=0):
        self.account_number = account_number
        self.balance = balance

    def deposit(self, amount):
        if amount > 0:
            self.balance += amount
        else:
            print("Deposit amount must be positive.")

    def withdraw(self, amount):
        if amount > 0:
            if self.balance >= amount:
                self.balance -= amount
            else:
                print("Insufficient balance.")
        else:
            print("Withdrawal amount must be positive.")

    def get_balance(self):
        return self.balance

    def display_info(self):
        print("\nBank Account Details:")
        print("Account Number".ljust(20), "->", self.account_number)
        print("Balance".ljust(20), "->", self.get_balance())
        print("-" * 40)


# Subclass: SavingsAccount
class SavingsAccount(BankAccount):
    def __init__(self, account_number, balance=0, interest_rate=2.5):
        super().__init__(account_number, balance)
        self.interest_rate = interest_rate

    def add_interest(self):
        interest = (self.balance * self.interest_rate) / 100
        self.balance += interest
        print(f"Interest of {interest} added. New balance is {self.balance}.")

    def display_info(self):
        super().display_info()  # Display details from BankAccount
        print("Interest Rate".ljust(20), "->", f"{self.interest_rate}%")
        print("-" * 40)


# Example usage
# Creating and using a BankAccount object
bank_account = BankAccount("12345678", 1000)
bank_account.display_info()
bank_account.deposit(500)
bank_account.withdraw(300)
bank_account.display_info()

# Creating and using a SavingsAccount object
savings_account = SavingsAccount("87654321", 2000)
savings_account.display_info()
savings_account.add_interest()  # Add interest
savings_account.display_info()
