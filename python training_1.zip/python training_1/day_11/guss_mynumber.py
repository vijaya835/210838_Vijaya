
import random

class guss(object):
    
   
    def __init__(self,number):
        self.number=number
   
def guessing_game():
    # Generate a random number between 1 and 100
    number_to_guess = random.randint(1, 100)
    max_attempts = 10
    attempts = 0
 
    print("Guess a number between 1 and 100: ")
 
    while attempts < max_attempts:
        guess = int(input())
 
        attempts += 1
 
        if guess == number_to_guess:
            print(f"Excellent playing! You guessed the number in {attempts} tries.")
            break
        elif guess < number_to_guess:
            print(f"Your guess is too low. You have {max_attempts - attempts} tries left.")
        else:
            print(f"Your guess is too high. You have {max_attempts - attempts} tries left.")
       
    if guess != number_to_guess:
        print(f"Sorry! You didn't guess the number. The number was {number_to_guess}.")
 
# Run the guessing game
guessing_game()
 
