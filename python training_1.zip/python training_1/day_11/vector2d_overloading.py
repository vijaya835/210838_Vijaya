class vector2D(object):

    def __init__(self, x, y):
        self.horizondal = x
        self.vertical  = y

    def __add__(self, other): # for overloading + => a + b => a -> self b -> other
        return vector2D(self.horizondal + other.horizondal,self.vertical + other.vertical)
    
    def __sub__(self, other): # for overloading + => a + b => a -> self b -> other
        return vector2D(self.horizondal - other.horizondal,self.vertical - other.vertical)
    
    def __eq__(self, other): # for overloading + => a + b => a -> self b -> other
        return (self.horizondal == other.horizondal and self.vertical == other.vertical)
    
    def __str__(self):
        return f"{self.horizondal},{self.vertical}"
    
v1 = vector2D(3,4)
v2 = vector2D(1,2)
 
v3 = v1+v2
print("v1+v2 =", v3)
 
v4 = v1-v2
print("v1-v2=", v4)
 
print("v3 == vector(4,6):", v3 ==vector2D(4,6))
print("v4 == vector(2,3):", v4 == vector2D(2,2))

