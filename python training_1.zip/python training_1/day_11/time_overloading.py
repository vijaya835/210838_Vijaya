class time(object):
    
    def__init_(self,hours, minutes, seconds):
