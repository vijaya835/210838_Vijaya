path = r"C:\Users\210838\Documents\python_traning\day_12\students.csv"
f = open(path)
content = f.readlines()
f.close()

print("INFO -> step 1", content)

# Step 2
# Process the content and store in a data structure
# What data structure will be good here? Sanjeev -> Dictionary
# student_dict -> class_dict

class_dict = {}
columns = [item.strip() for item in content[0].split(',')] # Keys of the student dictionary
for dataitem in content[1:]:
    values = [item.strip() for item in dataitem.split(',')] # Values for the student dictionary
    students_dict = dict(zip(columns, values)) # Zipping keys and values to form the student dictionary
    class_dict[students_dict['regid']] = students_dict # Adding student dictionery to class dictionary

    scores = [int(students_dict['phy']), int(students_dict['chem']), int(students_dict['math']), int(students_dict['bio'])]

    students_dict['avg'] = sum(scores) /len(scores)

    class_dict[students_dict['regid']] = students_dict



print("\n" + "-"*100)
print("INFO -> step 2 \n", class_dict)

sorted_students = sorted(class_dict.values(), key=lambda x: float(x['avg']), reverse=True)


# Assign ranks to students
for rank, student in enumerate(sorted_students, start=1):
    student['rank'] = rank
    class_dict[student['regid']] = student

# Step 3
# Calculate the average


print("\n" + "-"*100)
print("INFO -> step 3 -> Class dictionary after averages updated\n", class_dict)

# Step 4
# Calculate the rank

output_path = r"C:\Users\210838\Documents\python_traning\day_12\students_ranked.csv"
with open(output_path, mode='w') as file:
    # Define the headers
    headers = columns + ['avg', 'rank']
    file.write(','.join(headers) + '\n')
   
    
    for student in sorted_students:
        row = [student[key] for key in headers]
        file.write(','.join(map(str, row)) + '\n')

print("\n" + "-"*100)
print("INFO -> step 4 -> Class dictionary after ranks updated\n", class_dict)

template = "{0:8} | {1:15} | {2:5} | {3:5} | {4:5} | {5:5} | {6:5} | {7:5} | {8:5}"
line = '-'*90

print("\nCLASS REPORT")
print(line)
print(template.format('REGID', 'NAME', 'AGE', 'PHY', 'CHEM', 'MATH', 'BIO', 'AVG', 'RANK'))
print(line)
for regid in class_dict.keys():
    name = class_dict[regid]['name']
    id = class_dict[regid]['regid']
    age = class_dict[regid]['age']
    phy = class_dict[regid]['phy']
    chem = class_dict[regid]['chem']
    math = class_dict[regid]['math']
    bio = class_dict[regid]['bio']
    avg = class_dict[regid]['avg']
    rank = class_dict[regid]['rank']
    print(template.format(id, name, age, phy, chem, math, bio, avg, rank))
  
print(line)
file= open("student_report_value1.txt","w")
file.write("Class Result\n")
file.write(line + "\n")
file.write(template.format('REGID', 'NAME', 'AGE', 'PHY', 'CHEM', 'MATH', 'BIO', 'AVG', 'RANK') + "\n")
file.write(line + "\n")
for student in sorted_students:
    name = student['name']
    id = student['regid']
    age = student['age']
    phy = student['phy']
    chem = student['chem']
    math = student['math']
    bio = student['bio']
    avg = student['avg']
    rank = student['rank']
    file.write(template.format(id, name, age, phy, chem, math, bio, avg, rank)+"\n")
file.write(line + "\n")