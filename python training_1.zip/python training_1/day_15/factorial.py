# Create a NegativeNumberException
 
# Define a nfactorial(n) function in which the above exception is raised
 
# Use an exception handler to capture the exception when factorial() is
# called with negative numbers

class NegetiveNomberException(Exception):
    def __init__(self,no,message="Number should not be Negetive"):
        self.message = message
        self.no = no
        super().__init__(message,)
    def __str__(self):
        return f"{self.message} -> Given: {self.no}"
 
class nfactorial:
    def __init__(self,no):
        self.no = no
 
    def factorial(self):
        fact = 1
        if self.no < 0:
            raise NegetiveNomberException(self.no)
        while self.no != 0:
            fact = fact * self.no
            self.no = self.no - 1
        return (fact)
 
p = nfactorial(-5)
print(p.factorial())
