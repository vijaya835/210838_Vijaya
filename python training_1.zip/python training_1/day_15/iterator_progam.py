
#Create a text-processing tool that reads a paragraph and returns each word 
#one at a time when iterated over. You want to build a custom iterator 
#class called WordIterator that takes a string of text and lets users 
#iterate through its words using a for loop or next().



class WordIterator:
    def __init__(self, text):
        self.words = text.split()  # Split the text into words
        self.index = 0  # Start at the first word

    def __iter__(self):
        return self  # Return the iterator object itself

    def __next__(self):
        if self.index < len(self.words):  # Check if there are more words
            word = self.words[self.index]
            self.index += 1  # Move to the next word
            return word
        else:
            raise StopIteration  # No more words to iterate over


# Example usage
paragraph = "Python is a powerful and versatile programming language."

word_iterator = WordIterator(paragraph)

for word in word_iterator:  # Use a for loop to iterate through words
    print(word)