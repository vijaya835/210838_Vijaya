# Task 2: Injecting methods
# --------------------------------------------------

# Create a metaclass called AutoInit that automatically injects an __init__ method into 
# any class that:

# Defines a class-level list called init_fields, e.g., ["name", "salary"].

# If the __init__ method already exists, the metaclass should not override it.

# The injected __init__ should assign values to those fields as instance attributes.

# Raise an error if the init_fields list is missing or not a list.
class AutoInit(type):
    def __new__(cls, name, bases, dct):
        # Check if init_fields is defined
        if 'init_fields' not in dct:
            raise TypeError(f"Class '{name}' must define a class-level 'init_fields' attribute")

        # Check if init_fields is a list
        if not isinstance(dct['init_fields'], list):
            raise TypeError(f"Class '{name}' must have 'init_fields' as a list")

        # If __init__ is not already defined, inject one
        if '__init__' not in dct:
            def __init__(self, *args, **kwargs):
                if len(args) > len(dct['init_fields']):
                    raise TypeError(f"{name} accepts at most {len(dct['init_fields'])} positional arguments, but {len(args)} were given")

                for field, value in zip(dct['init_fields'], args):
                    setattr(self, field, value)

                for field in dct['init_fields'][len(args):]:
                    if field in kwargs:
                        setattr(self, field, kwargs[field])
                    else:
                        raise TypeError(f"Missing required keyword argument: '{field}'")

            dct['__init__'] = __init__

        return super().__new__(cls, name, bases, dct)


# Example of a class using the AutoInit metaclass
class Employee(metaclass=AutoInit):
    init_fields = ["name", "salary"]

# Example of a valid instance creation
employee = Employee("John Doe", salary=50000)
print(f"Name: {employee.name}, Salary: {employee.salary}")
          