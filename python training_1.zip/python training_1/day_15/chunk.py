user_ids=list(range(1, 10001)) 
def chunck_list(lst,chunk_size):
     for i in range(0, len(lst), chunk_size):
        yield lst [i:i+chunk_size]
     
for chunk in chunck_list(user_ids, 100):
      print(f"Processing chunk: {chunk[:3]}...{chunk[-3:]}")