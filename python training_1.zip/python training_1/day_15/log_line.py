# Generator
def filter_log_lines(log_lines, keyword):
    for log in log_lines:
        if keyword in log:
            yield log
log_lines = [
    "2025-04-07 INFO User logged in",
    "2025-04-07 ERROR Failed to load resource",
    "2025-04-07 DEBUG Memory usage stable",
    "2025-04-07 ERROR Timeout occurred",
    ]

for n in filter_log_lines(log_lines, "ERROR"):
    print(n)
