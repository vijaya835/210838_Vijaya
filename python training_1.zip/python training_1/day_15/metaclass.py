#Create a metaclass called RequireToString that ensures any class using it must define a 
#__str__ method. If a class does not define __str__, raise a TypeError during class creation.

class RequireToString(type):
    def __new__(cls, name, bases, dct):
        # Check if the class defines a __str__ method
        if '__str__' not in dct:
            raise TypeError(f"class does not define __str__")
        return super().__new__(cls, name, bases, dct)

class myclasswithstr(metaclass=RequireToString):
    pass
obj=myclasswithstr()
print(str(obj))