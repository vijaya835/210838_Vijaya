import json 
with open(r'C:\Users\210838\Documents\python_traning\day_13\student\students.json') as f:
    content=json.load(f)
    print(content)
    

print("INFO -> step 1", content)

# Step 2
# Process the content and store in a data structure
# What data structure will be good here? Sanjeev -> Dictionary
# student_dict -> class_dict

# Step 2: Process the content and store in a dictionary
class_dict = {}
 
for student in content:  
    class_dict[student['regid']] = student
 
 
# Step 3
# Calculate the average
def calculate_avg(marks):
    marks = list(map(float, marks))  
    return sum(marks) / len(marks)
 
for a, student in class_dict.items():  
    marks = [student['phy'], student['chem'], student['math'], student['bio']]  
    avg = calculate_avg(marks)  
    student['avg'] = avg
 
 
# Step 4
# Calculate the rank
 
sort_dict = sorted(class_dict.items(), key=lambda x: x[1]['avg'], reverse=True)
rank = 0
l = 0
for regid, student in sort_dict:
    a = student['avg']
    if l == a:
        student['rank'] = rank
    else:
        rank += 1
        student['rank'] = rank
    l = a
   
#print (sort_dict)
final_student_report = sorted(class_dict.items(), key=lambda x: x[1]['rank'])  
 
# # Step 5
# # Display the report
 
template = "| {0:<8} | {1:<8} | {2:<4} | {3:<5} | {4:<5} | {5:<5} | {6:<5} | {7:<5} | {8:<5} |"
line = '-' * 78
print("CLASS RESULT")
print(line)
print(template.format('REGID', 'NAME', 'AGE', 'PHY', 'CHEM', 'MATH', 'BIO', 'AVG', 'RANK'))
print(line)
 
for regid, student in final_student_report:
    name = student['name']
    id = student['regid']
    age = student['age']
    phy = student['phy']
    chem = student['chem']
    math = student['math']
    bio = student['bio']
    avg = student['avg']
    rank = student['rank']
    print(template.format(id, name, age, phy, chem, math, bio, avg, rank))
 
print(line)
 
 
 
## create the json file and copy the data
 
 
with open('students_report.json', 'w') as f:
    
    json.dump(final_student_report, f, indent=4)
