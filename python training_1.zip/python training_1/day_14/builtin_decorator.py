class circle:

    def __init__(self, radius):
        self.radius = radius
        

    @property
    def circumference(self):
        return 2 * 22/7 * self.radius

    @classmethod
    def from_diameter(cls, diameter):
        radius = diameter / 2
        return cls(radius)

    

    @staticmethod
    def valid_radius(value):
        return value >0

circle1 = circle(5)
print("Radius:", circle1.radius)
print("Circumference:", circle1.circumference)