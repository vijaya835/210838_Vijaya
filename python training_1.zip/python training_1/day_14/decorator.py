class log_function:

    def __init__(self, funcobj):
        self.f = funcobj
        print(f"Calling function:  {self.f.__name__}")

    def __call__(self, *arg ,**karg):
        print(f"Arguments:{arg}")
        result=self.f(*arg,**karg)
        return result

@log_function
def greet(name):
    print(f"Hello, {name}. How are you today?")

greet("Alice") 