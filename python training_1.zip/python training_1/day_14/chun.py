def chunk_string(string, chunk_size):
    """Generator to split a string into smaller chunks of given size."""
    for i in range(0, len(string), chunk_size):
        yield string[i:i + chunk_size]

# Usage example
text = "This is an example of chunking a string into smaller parts."
for chunk in chunk_string(text, 10):  # Chunk the string into parts of length 10
    print(chunk)
