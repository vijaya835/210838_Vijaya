class BankAccount:
    def __init__(self, name, balance=0):
        """Initialize the bank account with a name and an optional balance."""
        self.name = name
        self.balance = balance

    @property
    def current_balance(self):
        """Return the current balance of the account."""
        return self.balance

    @classmethod
    def from_dict(cls, data):
        """Create a BankAccount instance from a dictionary."""
        return cls(name=data['name'], balance=data['balance'])

    @staticmethod
    def valid_withdrawal(balance, amount):
        """
        Check if the withdrawal amount is valid.
        Returns True if the withdrawal is possible; otherwise, False.
        """
        return balance >= amount

    def deposit(self, amount):
        if amount > 0:
            self.balance += amount
            print(f"Deposited {amount}. New balance: {self.balance}")
        else:
            print("Invalid deposit amount!")

    def withdraw(self, amount):
        if self.valid_withdrawal(self.balance, amount):
            self.balance -= amount
            print(f"Withdrawn {amount}. New balance: {self.balance}")
        
account1 = BankAccount("Alice", 10000)

# Access the current balance
print(f"Current Balance: {account1.current_balance}")

# Deposit money
account1.deposit(500)

# Withdraw money
account1.withdraw(3000)

# Attempt to withdraw more than the balance
account1.withdraw(20000)

# Create an account using from_dict
account_data = {"name": "Bob", "balance": 2000}
account2 = BankAccount.from_dict(account_data)
print(f"\nCreated account for {account2.name} with balance: {account2.balance}")

