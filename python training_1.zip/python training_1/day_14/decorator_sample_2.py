class double_result:

    def __init__(self, funcobj):
        self.f = funcobj
    

    def __call__(self,*arg,**karg):
        result=self.f(*arg,**karg)
        return result *2

@double_result
def add(x, y):
    return x + y

print(add(3, 4))