import time
def timing(func):
 def wrapper(*arg,**karg):
    start=time.time()
    result=func(*arg,**karg)
    end=time.time()
    print(f"function{func.__name__}took {end-start:.f} secound to run")
    return result
  