from collections import Counter
def characterMap(s):
   return dict(Counter(s))
value= input("Enter charactermap sentence:")
result=characterMap(value)
print(f"mapped characters: {result}")