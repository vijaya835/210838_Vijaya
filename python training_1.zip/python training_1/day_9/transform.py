def transform(s):
     return 
word=input("Transform a word:")
word_string = transform(word)
print(word_string)
