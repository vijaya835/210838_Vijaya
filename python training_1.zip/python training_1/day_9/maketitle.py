def makeTitle(s):
    print(s.title()) 
value = input("Enter a string to make a title: ") 
makeTitle(value)
