class Employee:
    def __init__(self, name, age, company, salary, tax_percentage):
        self.name = name  # Employee's name
        self.age = age  # Employee's age
        self.company = company  # Company the employee works for
        self.salary = salary  # Gross salary
        self.tax_percentage = tax_percentage  # Tax percentage to be deducted
    
    def calculate_cross_pay(self):
        """
        Calculate the cross pay (which is the same as salary).
        This could be extended to calculate other bonuses, allowances, etc.
        """
        return self.salary
    
    def calculate_tax(self):
        """
        Calculate the tax to be deducted based on the salary and tax percentage.
        """
        return (self.salary * self.tax_percentage) / 100
    
    def calculate_net_salary(self):
        """
        Calculate the net salary after tax deduction.
        """
        tax = self.calculate_tax()
        return self.salary - tax
    
    def display_employee_info(self):
        """
        Display all the details of the employee.
        """
        print(f"Employee Name: {self.name}")
        print(f"Age: {self.age}")
        print(f"Company: {self.company}")
        print(f"Gross Salary: ${self.salary}")
        print(f"Tax Deducted: ${self.calculate_tax():.2f}")
        print(f"Net Salary: ${self.calculate_net_salary():.2f}")

# Example usage
if __name__ == "__main__":
    # Creating an Employee object
    emp1 = Employee(name="John Doe", age=30, company="Tech Corp", salary=50000, tax_percentage=10)

    # Displaying employee information
    emp1.display_employee_info()
