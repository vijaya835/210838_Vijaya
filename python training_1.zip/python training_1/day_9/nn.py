def BobnBot (N, M, games, Q, queries):
    # Write your code here
    res = []
    for i in queries:
        c =0
        for j in games:
            m=True
            for k in range(len(i)):
                if i[k] != -1 and i[k] != j[i]:   
                    m= False
                    break
        if m:
            c+=1  
        res.append(c)                          
    return res
    pass