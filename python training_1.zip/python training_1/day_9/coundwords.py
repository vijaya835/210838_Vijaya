
def countWords(s):
    words = s.split()
    return len(words)
word=input("Print a word:")
word_string= countWords(word)
print(word_string)

