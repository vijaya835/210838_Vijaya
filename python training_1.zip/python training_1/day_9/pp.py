def BobnBot(N, M, games, Q, queries):
    # Initialize the result list
    res = []

    # Iterate through each query
    for i in queries:
        c = 0
        # Check each game in games
        for j in games:
            m = True
            # Compare each element in the query with the corresponding game
            for k in range(len(i)):
                if i[k] == -1 or i[k] == j[k]:  # Check if the query value is -1 or matches the game
                    continue
                else:
                    m = False  # If there's a mismatch, mark as False
                    break

            # If all conditions are satisfied, increment the counter
            if m:
                c += 1
        
        # Append the count for the current query to the result list
        res.append(c)

    return res

# Sample input
N, M = map(int, input().split())  # N = number of games, M = length of each game
games = [list(map(int, input().split())) for _ in range(N)]  # Input for N games
Q = int(input())  # Number of queries
queries = [list(map(int, input().split())) for _ in range(Q)]  # Input for Q queries


