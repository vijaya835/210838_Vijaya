def reverseword(s):
     return (s[::-1])
word=input("Print a word:")
word_string = reverseword(word)
print(word_string)

