def normalizeSpaces(s):
    return ' '.join(s.split())
space =input ("print a word:")
space_string = normalizeSpaces(space)
print(space_string)
