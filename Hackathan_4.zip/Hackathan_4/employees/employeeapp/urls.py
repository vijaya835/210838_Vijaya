from django.urls import path
from . import views

urlpatterns = [
    path('salary', views.salary_form, name='salary'),
    path('result', views.calculate_salary, name='result'),
    path('jumble', views.jumble_word, name='jumble'),
]