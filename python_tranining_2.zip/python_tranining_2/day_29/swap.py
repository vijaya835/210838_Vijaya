from abc import ABC, abstractmethod

class TimeMachineSwapper(ABC):
    def __init__(self, s: str, k: int):
        self.s = list(s)
        self.k = k
        self.n = len(s)

    @abstractmethod
    def is_valid_swap(self, a: int, b: int) -> bool:
        """Check if a swap between digits a and b is valid."""
        pass

    def perform_swaps(self) -> str:
        swaps_done = 0

        for i in range(self.n):
            if swaps_done == self.k:
                break

            best = self.s[i]
            best_pos = -1

            # Try to find the best valid swap from right of i
            for j in range(self.n - 1, i, -1):
                if self.is_valid_swap(int(self.s[i]), int(self.s[j])) and self.s[j] > best:
                    best = self.s[j]
                    best_pos = j

            if best_pos != -1:
                self.s[i], self.s[best_pos] = self.s[best_pos], self.s[i]
                swaps_done += 1

        if swaps_done < self.k:
            return "IMPOSSIBLE"
        return ''.join(self.s)

class HardSwapRule(TimeMachineSwapper):
    def is_valid_swap(self, a: int, b: int) -> bool:
        return abs(a - b) >= 3


# 👇 Example Usage
s = "7324"
k = 2

swapper = HardSwapRule(s, k)
result = swapper.perform_swaps()
print("Output:", result)