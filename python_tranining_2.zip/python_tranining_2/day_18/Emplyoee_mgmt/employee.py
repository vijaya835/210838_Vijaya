import uuid
 
class Employee():
    def __init__(self, name,department,designation,gross_salary,tax,bonus,net_salary,id=None):
        self.id = id if id else str(uuid.uuid4())
        self.name = name
        self.department =department
        self.designation = designation
        self.gross_salary=gross_salary
        self.tax=tax
        self.bonus=bonus
        self.net_salary=net_salary
 
    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "department": self.department,
            "designation": self.designation,
            "gross_salary":self.gross_salary,
            "tax": self.tax,
            "bonus":self.bonus,
            "net_salary":self.gross_salary
        }
 
    @staticmethod
    def from_dict(data):
        return Employee(
            id=data["id"],
            name=data["name"],
            department=data["department"],
            designation=data["designation"],
            gross_salary=data["gross_salary"],
            tax=data["tax"],
            bonus=data["bonus"],
            net_salary=data["net_salary"]  
        )