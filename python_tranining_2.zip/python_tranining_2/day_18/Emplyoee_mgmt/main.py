from employee_manager import EmployeeManager
from storage import Storage
 
def display_employees(employees):
    if not employees:
        print("No employees found.")
    for s in employees:
        print(f"{s.id} - {s.name}, department: {s.department}, designation: {s.designation},gross_salary:{s.gross_salary},tax:{s.tax},bonus:{s.bonus},net_salary:{s.net_salary}")
 
def main():
    manager = EmployeeManager()
    storage = Storage()
 
    saved_data = storage.load()
    manager.load_employees(saved_data)
 
    while True:
        print("\n1. Add a new employee\n2. View all employees\n3. Search employee by ID\n4. Delete an employee\n5. Exit")
        choice = input("Enter choice: ")
 
        if choice == '1':
            name = input("Name: ")
            department = input("department: ")
            designation = input("designation: ")
            gross_salary=float(input("gross_salary: "))
            tax=float(input("tax: "))
            bonus=float(input("bonus: "))
            net_salary=gross_salary - tax + bonus
            employee = manager.add_employee(name, department,designation,gross_salary,tax,bonus,net_salary)
            storage.save(manager.to_dict_list())
            print(f"employee added with ID: {employee.id}")
 
        elif choice == '2':
            display_employees(manager.get_all_employee())
 
        elif choice == '3':
            sid = input("Enter employee ID: ")
            employee = manager.find_by_id(sid)
            if employee:
                print(f"{employee.id} - {employee.name}, department: {employee.department}, designation: {employee.designation},gross_salary:{employee.gross_salary},tax:{employee.tax},bonus:{employee.bonus},net_salary:{employee.net_salary} ")
            else:
                print("net_salary not found.")
 
        elif choice == '4':
            sid = input("Enter employee ID: ")
            if manager.delete_employee(sid):
                storage.save(manager.to_dict_list())
                print("employee deleted.")
            else:
                print("employee not found.")
 
        elif choice == '5':
            print("Exiting.")
            break
 
        else:
            print("Invalid choice!")
 
if __name__ == "__main__":
    main()