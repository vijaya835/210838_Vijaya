import unittest
import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
 
from storage import Storage
from employee import Employee
 
class TestStorage(unittest.TestCase):
    def setUp(self):
        self.storage = Storage("test_employees.pkl")
        self.test_data = [
            Employee("kamni", "Dept", "Role", "30000", "2000", "500", "28500").to_dict()
        ]
 
    def test_save_and_load(self):
        self.storage.save(self.test_data)
        loaded = self.storage.load()
        self.assertEqual(len(loaded), 1)
        self.assertEqual(loaded[0]["name"], "kamni")
 
    def tearDown(self):
        if os.path.exists("test_employee.pkl"):
            os.remove("test_employee.pkl")
 
if __name__ == "__main__":
    unittest.main()