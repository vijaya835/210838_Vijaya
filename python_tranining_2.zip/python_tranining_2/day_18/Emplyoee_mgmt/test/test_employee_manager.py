import unittest
import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
 
from employee_manager import EmployeeManager
 
class TestEmployeeManager(unittest.TestCase):
    def setUp(self):
        self.manager = EmployeeManager()
 
    def test_add_and_get_all(self):
        emp = self.manager.add_employee("priya", "medicine", "doctor", "500000", "10000", "3000", "49300")
        all_emps = self.manager.get_all_employee()
        self.assertEqual(len(all_emps), 1)
        self.assertEqual(all_emps[0].name, "priya")
 
    def test_find_by_id(self):
        emp = self.manager.add_employee("Raji", "Finance", "Analyst", 60000, 12000, 4000, 63000)
        found = self.manager.find_by_id(emp.id)
        self.assertIsNotNone(found)
        self.assertEqual(found.name, "Raji")
 
    def test_delete_employee(self):
        emp = self.manager.add_employee("Gomathi", "IT", "Developer", 70000, 2000, 5000, 748000)
        result = self.manager.delete_employee(emp.id)
        self.assertTrue(result)
        self.assertEqual(len(self.manager.get_all_employee()), 0)
 
 
if __name__ == "__main__":
    unittest.main()
 
 