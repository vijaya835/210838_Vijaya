
import unittest
import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
 
from employee import Employee
 
class TestEmployee(unittest.TestCase):
    def test_create_employee(self):
        emp = Employee("priya", "HR", "telent team", "500000", "2000", "4000", "500000")
        self.assertEqual(emp.name, "priya")
        self.assertEqual(emp.department, "HR")
        self.assertEqual(emp.designation, "telent team")
        self.assertEqual(emp.gross_salary, "500000")
   
    def test_to_dict(self):
        emp = Employee("Saji", "HR", "Manger", "550000", "10000","50000", "550000")
        data = emp.to_dict()
        self.assertEqual(data["name"], "Saji")
 
    def test_from_dict(self):
        data = {
            "name": "Saji",
            "department": "HR",
            "designation": "Mange",
            "gross_salary": "550000",
            
        }
        emp = Employee.from_dict(data)
        self.assertEqual(emp.name, "Saji")
 
if __name__ == "__main__":
    unittest.main()
 
