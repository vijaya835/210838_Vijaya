
# You are designing a system to rank products based on their ratings (on a scale of 0 to 5). 
# Two products are considered equal if their ratings are equal. A product with a lower rating 
# is considered less than one with a higher rating.
from functools import total_ordering

@total_ordering
class Product:  # Use the same class name to avoid confusion
    def __init__(self, name, rating):
        self.name = name
        self.rating = rating

    def __eq__(self, other):
        if not isinstance(other, Product):
            return NotImplemented
        return self.rating == other.rating

    def __gt__(self, other):
        if not isinstance(other, Product):
            return NotImplemented
        return self.rating > other.rating

    def __repr__(self):
        return f"{self.name}({self.rating})"

# === SAMPLE TEST CASE ===
if __name__ == "__main__":
    p1 = Product("Laptop", 4.5)
    p2 = Product("Tablet", 4.7)
    p3 = Product("Phone", 4.5)
    p4 = Product("Monitor", 4.2)

    products = [p1, p2, p3, p4]
    sorted_products = sorted(products)  # Sort in ascending order of rating
    print("Sorted products(ascending):", sorted_products)

    
    print("p1 == p3:", p1 == p3) 
    print("p1 < p2:", p1 < p2)    
    print("p2 >= p4:", p2 >= p4)