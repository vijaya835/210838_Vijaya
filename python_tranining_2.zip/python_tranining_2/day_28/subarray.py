class Solution(object):
    def countSubarrays(self, nums, k):
        for num in nums:  
            result = num * 1
            if result < k:
                print(f"{num} * 1 = {result} less than value of K") 
            else:
                print(f"{num} * 1 = {result} not less than K")    


nums = [1, 2, 3, 4, 5]
K = 10
solution = Solution()
solution.countSubarrays(nums, K) 