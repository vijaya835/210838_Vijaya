def merge_the_tools(string, k):
    for i in range(0, len(string), k):  # Use 'string' instead of 's'
        substring = string[i:i+k]
        unique_chars = "".join(dict.fromkeys(substring))  # Removes duplicates while keeping order
        print(unique_chars)
if __name__ == '__main__':
    string, k = input(), int(input())
    merge_the_tools(string, k)        