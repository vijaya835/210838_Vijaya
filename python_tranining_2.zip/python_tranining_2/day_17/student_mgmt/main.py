from Student_data import Student_data
from storage import Storage
 
def main():
    def display_students(students: list) -> None:
        if not students:
            print("No students to display.")
        else:
            for student in students:
                print(f"[{student.id}] Name: {student.name}, Age: {student.age}, Grade: {student.grade}")
 
    # Initialize Student manager and Storage
    manager = Student_data()
    store = Storage()
 
    # Load saved students from storage
    saved_student = store.load()
    manager.load_tasks(saved_student)
 
    while True:
        print("\n=== Student Management System ===")
        print("1. Add new student")
        print("2. View all students")
        print("3. Search student by ID")
        print("4. Delete a student")
        print("5. Exit")
 
        choice = input("Choice -> ")
 
        if choice == '1':
            name = input("Enter name: ").strip()
            age = input('Enter age: ').strip()
            grade = input('Enter grade: ').strip()
 
            if name:
                student = manager.add_student(name, age, grade)
                store.save(manager.to_dict_list())
                print(f"✅ Student added with ID: {student.id}")
            else:
                print("⚠️ Name cannot be empty.")
 
        elif choice == '2':
            student = manager.get_all_student()
            display_students(student)
 
        elif choice == '3':
            sid = input("Enter the Student ID to search: ").strip()
            student = manager.search_student(sid)
            if student:
                print(f"🔍 Found: Name: {student.name}, Age: {student.age}, Grade: {student.grade}")
            else:
                print("❌ Student ID not found.")
 
        elif choice == '4':
            sid = input("Enter the Student ID to delete: ").strip()
            if manager.delete_student(sid):
                store.save(manager.to_dict_list())
                print("🗑️ Student deleted.")
            else:
                print("❌ Student ID not found.")
 
        elif choice == '5':
            print("👋 Goodbye!")
            break
 
        else:
            print("❌ Invalid choice. Please select 1-5.")
 
if __name__ == "__main__":
    main()
 
 