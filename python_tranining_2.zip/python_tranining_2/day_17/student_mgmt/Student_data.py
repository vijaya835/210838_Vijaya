from students import Student
 
class Student_data(object):
    def __init__(self):
        self.data = []
 
    # Add new student
    def add_student(self, name, age, grade):
        student = Student(name, age, grade)
        self.data.append(student)
        return student
 
    # View all students
    def get_all_student(self):
        return self.data
 
    # Search student by ID
    def search_student(self, student_id):
        for student in self.data:
            if student.id == student_id:
                return student
        print(" No student found with that ID.")
        return None
 
    # Delete a student by ID
    def delete_student(self, student_id):
        for student in self.data:
            if student.id == student_id:
                self.data.remove(student)
                return True
        return False
 
    # Load students from a list of dictionaries
    def load_tasks(self, student_dicts):
        self.data = [Student.from_dict(td) for td in student_dicts]
 
    # Convert students to list of dictionaries
    def to_dict_list(self):
        return [student.to_dict() for student in self.data]