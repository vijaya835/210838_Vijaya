import unittest
import os
from storage import Storage

class TestStorage(unittest.TestCase):

    def setUp(self):
        self.filepath = 'test_storage.json'
        self.storage = Storage(self.filepath)

    def test_save_and_load(self):
        student_list = [
            {"id": "1", "name": "Test 1", "age": 1, "grade" :"A" },
            {"id": "2", "name": "Test 2", "age": 2, "grade" :"B" }
        ]

        self.storage.save(student_list)
        loaded = self.storage.load()
        self.assertEqual(len(loaded), 2)
        self.assertEqual(loaded[0]['id'], "1")
        self.assertEqual(loaded[1]['id'], "2")
        self.assertEqual(loaded[0]['name'], "Task 1")
        self.assertEqual(loaded[1]['name'], "Task 2")
        self.assertEqual(loaded[0]['age'], 1)
        self.assertEqual(loaded[1]['age'], 2)
        self.assertEqual(loaded[0]['grade'],"A")
        self.assertEqual(loaded[1]['grade'], "B")

    def tearDown(self):
        if os.path.exists(self.filepath):
            os.remove(self.filepath)