import unittest
from Student_data import TestManager

class TestManager(unittest.TestCase):

    def setUp(self):
        self.tm = TestManager()

    def test_add_and_get_student(self):
        self.tm.add_task("Test 1")
        self.tm.add_task("Test 2")
        students = self.tm.get_all_student()
        self.assertEqual(len(students), 2)

    def test_complete_student(self):
        task = self.tm.add_task("Task 1")
        result = self.tm.complete_task(task.id)
        self.assertTrue(result)
        self.assertTrue(task.completed)

    def test_delete_student(self):
        task = self.tm.add_task("Test 1")
        result = self.tm.delete_task(task.id)
        self.assertTrue(result)
        self.assertEqual(len(self.tm.get_all_students()), 0)

    def test_delete_nonexistent_students(self):
        result = self.tm.delete_task("non-existent-id")
        self.assertFalse(result)

    def tearDown(self):
        return None