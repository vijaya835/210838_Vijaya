import unittest
from students import student  # Import the `student` class
from Student_data import student_data  # Import the `student_Manager` class

class TestStudentManager(unittest.TestCase):

    def setUp(self):
        # Create an instance of the student_Manager before each test
        self.manager = student_data()

    def test_add_student(self):
        # Test adding a student
        student_obj = self.manager.add_student(name="John Doe", age=20, grade="A")
        self.assertEqual(len(self.manager.student), 1, "Student list length should be 1 after adding a student.")
        self.assertEqual(student_obj.name, "John Doe", "Student name should be 'John Doe'.")
        self.assertEqual(student_obj.age, 20, "Student age should be 20.")
        self.assertEqual(student_obj.grade, "A", "Student grade should be 'A'.")

    def test_get_all_students(self):
        # Test retrieving all students
        self.manager.add_student(name="John Doe", age=20, grade="A")
        self.manager.add_student(name="Jane Smith", age=22, grade="B")
        students = self.manager.get_all_tasks()
        self.assertEqual(len(students), 2, "Student list length should be 2.")
        self.assertEqual(students[0].name, "John Doe", "First student name should be 'John Doe'.")
        self.assertEqual(students[1].name, "Jane Smith", "Second student name should be 'Jane Smith'.")

    def test_delete_student(self):
        # Test deleting a student
        student_obj = self.manager.add_student(name="John Doe", age=20, grade="A")
        result = self.manager.delete_student(student_obj.id)
        self.assertTrue(result, "Deletion should return True.")
        self.assertEqual(len(self.manager.student), 0, "Student list length should be 0 after deletion.")

    def test_search_student(self):
        # Test searching for a student
        student_obj = self.manager.add_student(name="John Doe", age=20, grade="A")
        found_student = self.manager.search_student(student_obj.id)
        self.assertEqual(found_student.name, "John Doe", "Searched student name should be 'John Doe'.")
        not_found = self.manager.search_student("non_existent_id")
        self.assertEqual(not_found, "Student record not found for this ID", "Search should return error message for invalid ID.")

    def test_load_students(self):
        # Test loading students from a dictionary list
        student_data = [
            {"name": "John Doe", "age": 20, "grade": "A"},
            {"name": "Jane Smith", "age": 22, "grade": "B"}
        ]
        self.manager.load_student(student_data)
        self.assertEqual(len(self.manager.student), 2, "Student list length should match the loaded data length.")
        self.assertEqual(self.manager.student[0].name, "John Doe", "First loaded student name should be 'John Doe'.")

    def test_to_dict_list(self):
        # Test converting students to a list of dictionaries
        self.manager.add_student(name="John Doe", age=20, grade="A")
        self.manager.add_student(name="Jane Smith", age=22, grade="B")
        student_dict_list = self.manager.to_dict_list()
        self.assertEqual(len(student_dict_list), 2, "Dictionary list length should match the student list length.")
        self.assertEqual(student_dict_list[0]["name"], "John Doe", "First student's name in dictionary should be 'John Doe'.")
        self.assertEqual(student_dict_list[1]["grade"], "B", "Second student's grade in dictionary should be 'B'.")

    def tearDown(self):
        # Clean up after each test
        del self.manager

if __name__ == "__main__":
    unittest.main()